from django.apps import AppConfig


class RestfulUsersConfig(AppConfig):
    name = 'restful_users'
