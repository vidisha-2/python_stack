from django.db import models

class User(models.Model):
      first_name = models.CharField(max_length=200)
      last_name = models.CharField(max_length=200)
      email_address = models.EmailField()
      age = models.IntegerField()
      created_at = models.DateTimeField(auto_now_add=True)
      updated_at = models.DateTimeField(auto_now=True)
      def __repr__(self):
      	return "<User object: {} {} {} {}>".format(self.first_name, self.last_name, self.email_address, self.age)