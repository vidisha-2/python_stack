from django.apps import AppConfig


class BookLikesConfig(AppConfig):
    name = 'book_likes'
